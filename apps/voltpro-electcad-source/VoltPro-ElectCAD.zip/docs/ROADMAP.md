# VoltPro ElectCAD — engineering handoff and roadmap

## Product direction
Build an original, modular electrical CAD and circuit-design environment with workflows familiar to electrical engineers: project/page structure, symbol libraries, wire numbering, cross-references, terminal planning, bills of materials, reports, and eventually circuit simulation. Product inspiration may be drawn from public workflows in EPLAN Electric P8, WSCAD ELECTRIX, and AutoCAD Electrical; do not copy proprietary UI assets, source code, libraries, or branding.

## Milestone 0 — scaffold (current)
- [x] React/TypeScript/Vite frontend
- [x] Express/TypeScript REST API
- [x] CAD-like layout with menu, toolbar, symbol palette, canvas, project tree, inspector
- [x] Place basic symbols on canvas
- [x] Select and inspect placed symbols
- [x] Draw simple wires between points
- [x] Backend health and starter project endpoints
- [x] CI build workflow
- [ ] Persist projects in a database
- [ ] Add unit and end-to-end tests

## Milestone 1 — editor foundations
1. Define versioned JSON schema for projects, sheets, symbols, ports, wires, labels, and metadata.
2. Implement undo/redo command history and autosave.
3. Add selection rectangle, move, rotate, duplicate, delete, align, snap-to-grid, zoom-to-fit, and keyboard shortcuts.
4. Make wire endpoints attach to symbol ports rather than arbitrary coordinates.
5. Add layers, sheet title blocks, page numbering, and print/PDF export.
6. Add component library search, favorites, and user-defined symbols.

## Milestone 2 — electrical intelligence
1. Model electrical connectivity as a graph, independent from drawing geometry.
2. Add stable component IDs, terminal IDs, net IDs, and wire IDs.
3. Implement net highlighting and connectivity validation.
4. Add configurable wire numbering and cross-reference generation.
5. Generate terminal strip plans, cable schedules, bills of materials, and device lists.
6. Add manufacturer part data only from licensed, traceable sources.

## Milestone 3 — standards and interoperability
1. Add symbol variants and documented mapping to relevant IEC 60617 / EN / DIN conventions where legally available.
2. Treat standards compliance as versioned rules with tests and explicit coverage; never advertise compliance before verification.
3. Add import/export adapters: SVG/PDF first, then DXF/DWG via a suitable licensed SDK or tested open-source library.
4. Add project exchange format and migration/version support.
5. Verify German-language labels, decimal formatting, units, and DIN rail/control-cabinet workflows.

## Milestone 4 — simulation
1. Create a separate simulation domain model that maps schematic components to electrical models.
2. Integrate a SPICE-compatible solver or use a clearly documented adapter.
3. Support DC operating point first, then transient and AC analysis.
4. Display plots with units, analysis settings, and solver warnings.
5. Keep simulation separate from drafting geometry and report unsupported models explicitly.

## Milestone 5 — reliability and release
- Authentication, authorization, project sharing, audit trail, backups.
- Database migrations and API validation.
- Threat model, dependency scanning, CI tests, accessibility checks.
- Performance tests for large sheets and symbol libraries.
- Engineering review and clear disclaimer for non-certified outputs.
- Never use output as the sole basis for safety-critical installation decisions.

## Suggested architecture
- Frontend: React + TypeScript + Vite; SVG-based drawing layer initially.
- Backend: Node.js + Express + TypeScript with Zod validation.
- Storage: PostgreSQL for multi-user deployments; SQLite for local/single-user prototype.
- Simulation: isolated solver adapter, ideally a vetted SPICE implementation.
- Export: SVG/PDF first; DWG/DXF through a compliant SDK/adapter.
- Tests: Vitest for unit tests, Playwright for browser flows, API integration tests.

## First next tasks for the next engineer
1. Install dependencies and verify both builds.
2. Add Vitest and tests for editor actions and API routes.
3. Replace demo in-memory project with a versioned persistence layer.
4. Refactor `App.tsx` into toolbar, palette, canvas, inspector, and project-tree components.
5. Create a proper port/net model and endpoint snapping before implementing electrical validation.
