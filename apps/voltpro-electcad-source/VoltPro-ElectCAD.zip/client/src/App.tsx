import { useMemo, useRef, useState } from 'react';
import {
  Activity, AlignLeft, ArrowDownRight, ArrowLeftRight, ArrowUpRight, BatteryCharging,
  Box, Cable, Check, ChevronDown, CircleHelp, CircuitBoard, ClipboardList, Cloud,
  Code2, Copy, Download, FilePlus2, FileText, Folder, FolderOpen, Gauge, Grid2X2,
  Hand, Info, Layers, Lightbulb, Magnet, Minus, MousePointer2, PanelLeft, Plus,
  Redo2, Save, Search, Settings2, Share2, ShieldCheck, SlidersHorizontal, Square,
  Terminal, Trash2, Undo2, Upload, Waypoints, X, Zap
} from 'lucide-react';

type Tool = 'select' | 'wire' | 'resistor' | 'lamp' | 'switch' | 'ground' | 'power' | 'terminal';
type Part = { id: string; type: Exclude<Tool,'select'|'wire'>; x: number; y: number; ref: string; value: string };
type Wire = { id: string; x1: number; y1: number; x2: number; y2: number };
const palette: { type: Part['type']; label: string; icon: string; group: string }[] = [
  { type:'power',label:'Power supply',icon:'power',group:'Sources' },
  { type:'ground',label:'Ground',icon:'ground',group:'Sources' },
  { type:'resistor',label:'Resistor',icon:'resistor',group:'Passive' },
  { type:'lamp',label:'Lamp',icon:'lamp',group:'Output' },
  { type:'switch',label:'Switch',icon:'switch',group:'Control' },
  { type:'terminal',label:'Terminal',icon:'terminal',group:'Connections' },
];
const uid = () => Math.random().toString(36).slice(2,10);
function SymbolShape({part, selected=false}:{part:Part;selected?:boolean}) {
  const stroke = selected ? '#58d9c2' : '#dbe6ef';
  const common = {stroke,strokeWidth:2,fill:'#111e28',strokeLinecap:'round' as const,strokeLinejoin:'round' as const};
  return <g>
    <line x1={part.x-38} y1={part.y} x2={part.x-15} y2={part.y} {...common}/>
    <line x1={part.x+15} y1={part.y} x2={part.x+38} y2={part.y} {...common}/>
    {part.type==='resistor' && <rect x={part.x-15} y={part.y-9} width="30" height="18" rx="2" {...common}/>}
    {part.type==='lamp' && <g><circle cx={part.x} cy={part.y} r="15" {...common}/><path d={`M ${part.x-8} ${part.y-8} L ${part.x+8} ${part.y+8} M ${part.x+8} ${part.y-8} L ${part.x-8} ${part.y+8}`} {...common}/></g>}
    {part.type==='switch' && <g><circle cx={part.x-14} cy={part.y} r="3" {...common}/><circle cx={part.x+14} cy={part.y} r="3" {...common}/><line x1={part.x-12} y1={part.y-2} x2={part.x+9} y2={part.y-12} {...common}/></g>}
    {part.type==='ground' && <g><line x1={part.x} y1={part.y-10} x2={part.x} y2={part.y+7} {...common}/><path d={`M ${part.x-13} ${part.y+7} H ${part.x+13} M ${part.x-8} ${part.y+12} H ${part.x+8} M ${part.x-3} ${part.y+17} H ${part.x+3}`} {...common}/></g>}
    {part.type==='power' && <g><circle cx={part.x} cy={part.y} r="15" {...common}/><path d={`M ${part.x-7} ${part.y} H ${part.x+7} M ${part.x} ${part.y-7} V ${part.y+7}`} {...common}/></g>}
    {part.type==='terminal' && <rect x={part.x-11} y={part.y-11} width="22" height="22" {...common}/>}
    <text x={part.x} y={part.y+34} textAnchor="middle" fill={selected?'#58d9c2':'#9eb0bf'} fontSize="11">{part.ref}</text>
    <text x={part.x} y={part.y+47} textAnchor="middle" fill="#708493" fontSize="10">{part.value}</text>
  </g>;
}
export default function App() {
  const [tool,setTool] = useState<Tool>('select');
  const [parts,setParts] = useState<Part[]>([
    {id:'p1',type:'power',x:260,y:190,ref:'V1',value:'24 V DC'},
    {id:'p2',type:'switch',x:430,y:190,ref:'S1',value:'Switch'},
    {id:'p3',type:'lamp',x:600,y:190,ref:'H1',value:'Signal lamp'},
    {id:'p4',type:'ground',x:600,y:320,ref:'PE1',value:'Ground'}
  ]);
  const [wires,setWires] = useState<Wire[]>([]);
  const [selected,setSelected] = useState<string|null>('p2');
  const [projectName,setProjectName] = useState('Untitled electrical project');
  const [sheet,setSheet] = useState('01 — Main circuit');
  const [query,setQuery] = useState('');
  const [leftOpen,setLeftOpen] = useState(true);
  const [rightOpen,setRightOpen] = useState(true);
  const [grid,setGrid] = useState(true);
  const [snap,setSnap] = useState(true);
  const [zoom,setZoom] = useState(100);
  const [status,setStatus] = useState('All changes saved locally');
  const [menu,setMenu] = useState<string|null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const active = parts.find(p=>p.id===selected) ?? null;
  const filtered = useMemo(()=>palette.filter(p=>p.label.toLowerCase().includes(query.toLowerCase())),[query]);
  const grouped = ['Sources','Passive','Control','Output','Connections'];
  const addPart = (type:Part['type'], x=300+Math.random()*280, y=170+Math.random()*230) => {
    const counts=parts.filter(p=>p.type===type).length+1;
    const prefixes:Record<Part['type'],string>={power:'V',ground:'PE',resistor:'R',lamp:'H',switch:'S',terminal:'X'};
    setParts(prev=>[...prev,{id:uid(),type,x:Math.round(x/20)*20,y:Math.round(y/20)*20,ref:`${prefixes[type]}${counts}`,value:({power:'24 V DC',ground:'PE',resistor:'1 kΩ',lamp:'Signal lamp',switch:'Normally open',terminal:'1'} as Record<Part['type'],string>)[type]}]);
    setTool('select'); setStatus('Component placed');
  };
  const point = (e:React.MouseEvent<SVGSVGElement>) => {
    const rect=svgRef.current!.getBoundingClientRect();
    const scale=zoom/100;
    const x=(e.clientX-rect.left)/scale, y=(e.clientY-rect.top)/scale;
    return {x:snap?Math.round(x/20)*20:x,y:snap?Math.round(y/20)*20:y};
  };
  const onCanvasClick=(e:React.MouseEvent<SVGSVGElement>)=>{
    if(e.target!==svgRef.current && !(e.target as Element).classList.contains('canvas-bg')) return;
    const {x,y}=point(e);
    if(['power','ground','resistor','lamp','switch','terminal'].includes(tool)) addPart(tool as Part['type'],x,y);
    else if(tool==='select') setSelected(null);
  };
  const saveProject=()=>{
    const data={schemaVersion:1,projectName,activeSheet:sheet,parts,wires,exportedAt:new Date().toISOString()};
    const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=`${projectName.replace(/[^a-z0-9-_]/gi,'_')}.vpcad.json`; a.click(); URL.revokeObjectURL(url);
    setStatus('Project JSON exported');
  };
  const exportSvg=()=>{
    if(!svgRef.current)return;
    const clone=svgRef.current.cloneNode(true) as SVGSVGElement;
    clone.querySelectorAll('.canvas-bg').forEach(n=>n.remove());
    const source=new XMLSerializer().serializeToString(clone);
    const blob=new Blob([source],{type:'image/svg+xml'}); const url=URL.createObjectURL(blob);
    const a=document.createElement('a'); a.href=url; a.download='voltpro-schematic.svg'; a.click(); URL.revokeObjectURL(url); setStatus('SVG exported');
  };
  const deleteSelected=()=>{if(!selected)return;setParts(p=>p.filter(x=>x.id!==selected));setWires(w=>w.filter(x=>x.id!==selected));setSelected(null);setStatus('Item deleted');};
  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark"><Zap size={20} fill="currentColor"/></div><div><strong>VoltPro <span>ElectCAD</span></strong><small>ENGINEERING WORKSPACE</small></div></div>
      <div className="project-name"><span className="live-dot"/><input aria-label="Project name" value={projectName} onChange={e=>setProjectName(e.target.value)}/><ChevronDown size={15}/></div>
      <div className="top-actions"><button className="icon-btn" title="Undo"><Undo2 size={17}/></button><button className="icon-btn" title="Redo"><Redo2 size={17}/></button><span className="top-divider"/><button className="icon-btn" title="Settings"><Settings2 size={17}/></button><button className="avatar">VP</button></div>
    </header>
    <nav className="menubar">{['File','Edit','View','Insert','Electrical','Tools','Window','Help'].map(m=><div className="menu-wrap" key={m}><button className={menu===m?'menu-active':''} onClick={()=>setMenu(menu===m?null:m)}>{m}</button>{menu===m&&<div className="menu-pop">{(m==='File'?[['New project',()=>{setParts([]);setWires([]);setSelected(null);setProjectName('Untitled project')}],['Export project JSON',saveProject],['Export SVG',exportSvg]]:m==='Edit'?[['Delete selected',deleteSelected],['Select tool',()=>setTool('select')]]:m==='View'?[['Toggle symbol palette',()=>setLeftOpen(!leftOpen)],['Toggle inspector',()=>setRightOpen(!rightOpen)],['Toggle grid',()=>setGrid(!grid)]]:m==='Insert'?[['Resistor',()=>addPart('resistor')],['Lamp',()=>addPart('lamp')],['Switch',()=>addPart('switch')]]:m==='Electrical'?[['Power supply',()=>addPart('power')],['Ground',()=>addPart('ground')],['Terminal',()=>addPart('terminal')]]:m==='Tools'?[['Select tool',()=>setTool('select')],['Wire tool',()=>setTool('wire')]]:[['About VoltPro',()=>setStatus('VoltPro ElectCAD starter build')]]).map(([label,fn])=><button key={label as string} onClick={()=>{(fn as ()=>void)();setMenu(null)}}>{label as string}</button>)}</div>}</div>)}</nav>
    <div className="toolbar">
      <div className="toolgroup"><button className={tool==='select'?'tool-active':''} onClick={()=>setTool('select')} title="Select (V)"><MousePointer2 size={17}/><span>Select</span></button><button className={tool==='wire'?'tool-active':''} onClick={()=>setTool('wire')} title="Wire"><Cable size={17}/><span>Wire</span></button><button onClick={()=>setStatus('Move tool is planned')}><Hand size={17}/><span>Pan</span></button></div>
      <span className="v-sep"/>
      <div className="toolgroup"><button onClick={()=>addPart('resistor')}><span className="mini-resistor">▱</span><span>Component</span><ChevronDown size={12}/></button><button onClick={()=>setStatus('Label tool is planned')}><AlignLeft size={17}/><span>Label</span></button><button onClick={()=>setStatus('Measurement tool is planned')}><Gauge size={17}/><span>Measure</span></button></div>
      <span className="v-sep"/>
      <div className="toolgroup"><button className={grid?'tool-active':''} onClick={()=>setGrid(!grid)}><Grid2X2 size={16}/><span>Grid</span></button><button className={snap?'tool-active':''} onClick={()=>setSnap(!snap)}><Magnet size={16}/><span>Snap</span></button></div>
      <div className="toolbar-spacer"/><div className="zoom-control"><button onClick={()=>setZoom(Math.max(50,zoom-10))}><Minus size={14}/></button><span>{zoom}%</span><button onClick={()=>setZoom(Math.min(150,zoom+10))}><Plus size={14}/></button></div><button className="primary-btn" onClick={saveProject}><Save size={15}/> Save</button>
    </div>
    <main className="workspace">
      {leftOpen&&<aside className="left-sidebar">
        <div className="panel-heading"><div><PanelLeft size={15}/> <span>PROJECT EXPLORER</span></div><button className="tiny-btn" onClick={()=>setLeftOpen(false)}><X size={14}/></button></div>
        <div className="project-tree"><div className="tree-row tree-root"><FolderOpen size={15}/><span>{projectName}</span><ChevronDown size={13}/></div><div className="tree-child"><div className="tree-row"><Layers size={14}/><span>Sheets (1)</span><button className="tree-add" onClick={()=>setSheet('02 — New sheet')}><Plus size={13}/></button></div><button className="sheet-row" onClick={()=>setSheet('01 — Main circuit')}><FileText size={14}/><span>01 — Main circuit</span></button><button className="sheet-row" onClick={()=>setSheet('02 — Control circuit')}><FileText size={14}/><span>02 — Control circuit</span></button><div className="tree-row"><Folder size={14}/><span>Reports</span></div><div className="tree-row"><Folder size={14}/><span>Device list</span></div></div></div>
        <div className="panel-heading library-head"><div><CircuitBoard size={15}/><span>SYMBOL LIBRARY</span></div><span className="count-pill">{palette.length}</span></div>
        <div className="search-box"><Search size={15}/><input placeholder="Find a symbol..." value={query} onChange={e=>setQuery(e.target.value)}/><span>/</span></div>
        <div className="palette-scroll">{grouped.map(group=>{const items=filtered.filter(p=>p.group===group);return items.length?<div className="palette-group" key={group}><div className="group-label">{group}</div>{items.map(p=><button key={p.type} className={`palette-item ${tool===p.type?'palette-selected':''}`} onClick={()=>{setTool(p.type);setStatus(`${p.label} tool selected — click canvas to place`)}}><span className="symbol-preview">{p.type==='resistor'?'▱':p.type==='lamp'?'⊗':p.type==='switch'?'⌁':p.type==='ground'?'⏚':p.type==='power'?'⊕':'□'}</span><span>{p.label}</span><Plus size={13}/></button>)}</div>:null})}</div>
        <div className="library-footer"><ShieldCheck size={14}/><span>Starter IEC-style symbols · not certified</span></div>
      </aside>}
      <section className="canvas-area">
        <div className="canvas-header"><div className="breadcrumbs"><span>Projects</span><span>/</span><strong>{sheet}</strong><span className="draft-tag">DRAFT</span></div><div className="canvas-actions"><button onClick={exportSvg}><Download size={14}/> SVG</button><button onClick={saveProject}><Share2 size={14}/> Export</button></div></div>
        <div className="canvas-wrap">
          <svg ref={svgRef} className="schematic-canvas" viewBox="0 0 1100 700" onClick={onCanvasClick} style={{transform:`scale(${zoom/100})`}}>
            <rect className="canvas-bg" x="0" y="0" width="1100" height="700" fill="#101820"/>
            {grid&&<defs><pattern id="smallGrid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M 20 0 L 0 0 0 20" fill="none" stroke="#263744" strokeWidth=".65"/></pattern><pattern id="bigGrid" width="100" height="100" patternUnits="userSpaceOnUse"><rect width="100" height="100" fill="url(#smallGrid)"/><path d="M 100 0 L 0 0 0 100" fill="none" stroke="#344957" strokeWidth="1"/></pattern></defs>}
            {grid&&<rect className="canvas-bg" x="0" y="0" width="1100" height="700" fill="url(#bigGrid)"/>}
            {wires.map(w=><polyline key={w.id} points={`${w.x1},${w.y1} ${w.x2},${w.y1} ${w.x2},${w.y2}`} fill="none" stroke="#58d9c2" strokeWidth="2" strokeLinejoin="round"/>)}
            {parts.map(p=><g key={p.id} onClick={e=>{e.stopPropagation();setSelected(p.id);if(tool==='wire')setStatus('Wire mode: choose endpoints (connection engine planned)')}} style={{cursor:'pointer'}}><rect x={p.x-48} y={p.y-27} width="96" height="80" fill={selected===p.id?'#58d9c211':'transparent'} stroke={selected===p.id?'#58d9c2':'transparent'} strokeDasharray="4 4"/><SymbolShape part={p} selected={selected===p.id}/></g>)}
            <g opacity=".5"><rect x="840" y="570" width="230" height="95" fill="#14222d" stroke="#3c5362"/><text x="852" y="590" fill="#95aab9" fontSize="10">PROJECT</text><text x="852" y="608" fill="#dbe6ef" fontSize="12">{projectName.slice(0,27)}</text><text x="852" y="628" fill="#95aab9" fontSize="10">SHEET</text><text x="852" y="646" fill="#dbe6ef" fontSize="12">{sheet}</text></g>
          </svg>
          {parts.length===0&&<div className="empty-hint"><CircuitBoard size={28}/><strong>Start your schematic</strong><span>Choose a symbol from the library, then click the canvas.</span></div>}
          <div className="canvas-badge"><span className="live-dot"/> Schematic editor <span>·</span> IEC style</div>
          <div className="canvas-coordinates">X: 0240.0 <span>Y: 0160.0</span> <span>GRID 20</span></div>
        </div>
        <div className="bottom-dock"><div className="dock-tabs"><button className="dock-active"><Activity size={14}/> Diagnostics <span className="counter">0</span></button><button><Terminal size={14}/> Console</button><button><ClipboardList size={14}/> Reports</button></div><div className="diagnostic-content"><div className="diagnostic-icon"><Check size={15}/></div><div><strong>Workspace ready</strong><span>Starter editor loaded. Electrical rule checking is not yet implemented.</span></div><span className="diag-time">JUST NOW</span></div></div>
      </section>
      {rightOpen&&<aside className="right-sidebar">
        <div className="panel-heading"><div><SlidersHorizontal size={15}/><span>PROPERTIES</span></div><button className="tiny-btn" onClick={()=>setRightOpen(false)}><X size={14}/></button></div>
        {active?<div className="inspector">
          <div className="selected-part-icon">{active.type==='power'?<BatteryCharging/>:active.type==='ground'?<Zap/>:active.type==='resistor'?<Waypoints/>:active.type==='lamp'?<Lightbulb/>:active.type==='switch'?<ArrowLeftRight/>:<Square/>}</div>
          <div className="selected-part-name"><strong>{active.type[0].toUpperCase()+active.type.slice(1)}</strong><span>Electrical symbol · {active.id}</span></div>
          <div className="field"><label>Device tag</label><input value={active.ref} onChange={e=>setParts(ps=>ps.map(p=>p.id===active.id?{...p,ref:e.target.value}:p))}/></div>
          <div className="field"><label>Description / value</label><input value={active.value} onChange={e=>setParts(ps=>ps.map(p=>p.id===active.id?{...p,value:e.target.value}:p))}/></div>
          <div className="field-row"><div className="field"><label>Position X</label><input type="number" value={Math.round(active.x)} onChange={e=>setParts(ps=>ps.map(p=>p.id===active.id?{...p,x:Number(e.target.value)}:p))}/></div><div className="field"><label>Position Y</label><input type="number" value={Math.round(active.y)} onChange={e=>setParts(ps=>ps.map(p=>p.id===active.id?{...p,y:Number(e.target.value)}:p))}/></div></div>
          <div className="field"><label>Component type</label><div className="read-only-field">{active.type}<span>●</span></div></div>
          <div className="inspector-divider"/>
          <div className="section-label">ELECTRICAL DATA</div>
          <div className="data-row"><span>Reference</span><strong>{active.ref}</strong></div><div className="data-row"><span>Connection pins</span><strong>{active.type==='ground'?1:2}</strong></div><div className="data-row"><span>Library</span><strong>VoltPro Basic</strong></div>
          <button className="danger-btn" onClick={deleteSelected}><Trash2 size={14}/> Delete component</button>
        </div>:<div className="no-selection"><MousePointer2 size={23}/><strong>No selection</strong><span>Select a symbol on the canvas to edit its properties.</span></div>}
        <div className="inspector-bottom"><div className="section-label">DOCUMENT SETTINGS</div><div className="data-row"><span>Grid spacing</span><strong>20 units</strong></div><div className="data-row"><span>Snap to grid</span><button className={`switch ${snap?'switch-on':''}`} onClick={()=>setSnap(!snap)}><span/></button></div><div className="data-row"><span>Show grid</span><button className={`switch ${grid?'switch-on':''}`} onClick={()=>setGrid(!grid)}><span/></button></div><button className="outline-btn" onClick={()=>setStatus('Document settings opened (configuration planned)')}><Settings2 size={14}/> More settings</button></div>
      </aside>}
    </main>
    <footer className="statusbar"><div><span className="status-light"/>{status}</div><div className="status-right"><span><Check size={12}/> Ready</span><span>MM</span><span>GRID: {grid?'ON':'OFF'}</span><span>SNAP: {snap?'ON':'OFF'}</span><span>V0.1.0</span></div></footer>
  </div>;
}
