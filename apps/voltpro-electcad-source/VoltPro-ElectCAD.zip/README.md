# VoltPro ElectCAD

VoltPro ElectCAD is an original starter project for a browser-based electrical CAD workspace inspired by common workflows in professional electrical engineering tools such as EPLAN Electric P8, WSCAD, and AutoCAD Electrical. It is **not affiliated with or a clone of those products** and does not include their proprietary assets.

## Current scope
- React + TypeScript + Vite frontend
- Express + TypeScript backend API
- Interactive schematic workspace with grid, select/wire/component tools
- Starter component palette (power, ground, resistor, lamp, switch, relay, terminal)
- Project and sheet navigation, inspector sidebar, properties panel
- Local editor state and starter API health/project endpoints
- Responsive dark engineering UI
- Project roadmap and continuation notes

## Requirements
- Node.js 20+ and npm
- Git

## Run locally
Open two terminals:

### Backend
```bash
cd server
npm install
npm run dev
```
API listens on `http://localhost:4000`.

### Frontend
```bash
cd client
npm install
npm run dev
```
Open the Vite URL (usually `http://localhost:5173`).

## Build
```bash
cd server && npm install && npm run build
cd ../client && npm install && npm run build
```

## GitHub
Create an empty GitHub repository named `VoltPro-ElectCAD`, then:
```bash
git init
git add .
git commit -m "Initial VoltPro ElectCAD scaffold"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/VoltPro-ElectCAD.git
git push -u origin main
```
Do not commit `.env`, credentials, or generated `node_modules`.

## Architecture
- `client/`: React interface and schematic editor.
- `server/`: REST API with health and project endpoints.
- `docs/ROADMAP.md`: staged product roadmap and engineering handoff.
- `docs/ARCHITECTURE.md`: proposed data model, simulation approach, and safety boundaries.

## Important engineering status
This is a starter scaffold, not a certified electrical design tool. It does not yet perform electrical rule checking, validated circuit simulation, automatic DIN/IEC compliance verification, or production-grade DWG/DXF export. Any generated designs must be independently checked by a qualified engineer before real-world use.
